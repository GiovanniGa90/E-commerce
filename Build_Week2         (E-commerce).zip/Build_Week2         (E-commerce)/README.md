# BuildWeek2
E-commerce website
By Group5 
  members: Anish Frigerio, Federico Caramanti, Giovanni Galtioto, Joussoufa Seydi, Marina Muntenita.

Step 1: Install node modules on terminal with: npm i
Step 2: Run JSON server on terminal with: json-server --watch assets/data/data.json
Step 3: Open with Live Server.
